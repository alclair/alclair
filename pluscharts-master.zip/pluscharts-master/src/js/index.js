import {draw} from './chart';
export default draw;